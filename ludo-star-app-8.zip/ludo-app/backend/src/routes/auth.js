const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { requireAuth } = require('../middleware/auth');
const { signToken, publicUser } = require('../utils/token');

const router = express.Router();

const SIGNUP_BONUS = Number(process.env.SIGNUP_BONUS_COINS || 5000);
const DAILY_BONUS = Number(process.env.DAILY_BONUS_COINS || 5000);
const DAILY_BONUS_HOURS = Number(process.env.DAILY_BONUS_HOURS || 24);

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'تمام خانے پُر کریں' });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: 'پاس ورڈ کم از کم 6 حروف کا ہو' });
    }

    const existing = await User.findOne({
      $or: [{ email: email.toLowerCase() }, { username }],
    });
    if (existing) {
      return res.status(409).json({ message: 'یہ ای میل یا یوزرنیم پہلے سے موجود ہے' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({
      username,
      email: email.toLowerCase(),
      passwordHash,
      coins: SIGNUP_BONUS, // signup bonus
      lastBonusClaimedAt: null,
    });

    const token = signToken(user);
    res.status(201).json({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'سرور میں خرابی' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { emailOrUsername, password } = req.body;
    if (!emailOrUsername || !password) {
      return res.status(400).json({ message: 'تمام خانے پُر کریں' });
    }
    const user = await User.findOne({
      $or: [
        { email: emailOrUsername.toLowerCase() },
        { username: emailOrUsername },
      ],
    });
    if (!user) {
      return res.status(401).json({ message: 'غلط ای میل/یوزرنیم یا پاس ورڈ' });
    }
    if (user.isBanned) {
      return res.status(403).json({ message: 'آپ کا اکاؤنٹ بلاک کر دیا گیا ہے' });
    }
    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) {
      return res.status(401).json({ message: 'غلط ای میل/یوزرنیم یا پاس ورڈ' });
    }
    const token = signToken(user);
    res.json({ token, user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'سرور میں خرابی' });
  }
});

// GET /api/auth/me
router.get('/me', requireAuth, async (req, res) => {
  res.json({ user: publicUser(req.user) });
});

// POST /api/auth/claim-bonus  -> claims the 24h free coin bonus if available
router.post('/claim-bonus', requireAuth, async (req, res) => {
  try {
    const user = req.user;
    const now = new Date();
    const msSinceLast = user.lastBonusClaimedAt
      ? now - new Date(user.lastBonusClaimedAt)
      : Infinity;
    const cooldownMs = DAILY_BONUS_HOURS * 60 * 60 * 1000;

    if (msSinceLast < cooldownMs) {
      const remainingMs = cooldownMs - msSinceLast;
      return res.status(400).json({
        message: 'ابھی بونس کا وقت نہیں آیا',
        remainingMs,
      });
    }

    user.coins += DAILY_BONUS;
    user.lastBonusClaimedAt = now;
    await user.save();

    res.json({
      message: `${DAILY_BONUS} کوائنز مل گئے!`,
      coins: user.coins,
      lastBonusClaimedAt: user.lastBonusClaimedAt,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'سرور میں خرابی' });
  }
});

// GET /api/auth/bonus-status -> tells the frontend how long until next bonus
router.get('/bonus-status', requireAuth, async (req, res) => {
  const user = req.user;
  const now = new Date();
  const cooldownMs = DAILY_BONUS_HOURS * 60 * 60 * 1000;
  if (!user.lastBonusClaimedAt) {
    return res.json({ available: true, remainingMs: 0 });
  }
  const msSinceLast = now - new Date(user.lastBonusClaimedAt);
  const remainingMs = Math.max(0, cooldownMs - msSinceLast);
  res.json({ available: remainingMs <= 0, remainingMs });
});

module.exports = router;
