const express = require('express');
const User = require('../models/User');
const Match = require('../models/Match');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth, requireAdmin);

// GET /api/admin/overview -> quick stats for top of dashboard
router.get('/overview', async (req, res) => {
  const totalUsers = await User.countDocuments();
  const onlineUsers = await User.countDocuments({ isOnline: true });
  const totalCoinsAgg = await User.aggregate([
    { $group: { _id: null, total: { $sum: '$coins' } } },
  ]);
  const liveMatches = await Match.countDocuments({ status: 'active' });
  const totalMatches = await Match.countDocuments();

  res.json({
    totalUsers,
    onlineUsers,
    totalCoinsInCirculation: totalCoinsAgg[0]?.total || 0,
    liveMatches,
    totalMatches,
  });
});

// GET /api/admin/users -> paginated list of all users
router.get('/users', async (req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Number(req.query.limit) || 25);
  const search = req.query.search?.trim();

  const filter = search
    ? {
        $or: [
          { username: { $regex: search, $options: 'i' } },
          { email: { $regex: search, $options: 'i' } },
        ],
      }
    : {};

  const [users, total] = await Promise.all([
    User.find(filter)
      .select('-passwordHash')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit),
    User.countDocuments(filter),
  ]);

  res.json({ users, total, page, pages: Math.ceil(total / limit) });
});

// PATCH /api/admin/users/:id/ban -> toggle ban state
router.patch('/users/:id/ban', async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ message: 'یوزر نہیں ملا' });
  user.isBanned = !user.isBanned;
  await user.save();
  res.json({ message: user.isBanned ? 'یوزر بلاک ہو گیا' : 'یوزر ان بلاک ہو گیا', isBanned: user.isBanned });
});

// PATCH /api/admin/users/:id/coins -> manually adjust a user's coin balance
router.patch('/users/:id/coins', async (req, res) => {
  const { amount } = req.body; // can be positive or negative
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ message: 'یوزر نہیں ملا' });
  user.coins = Math.max(0, user.coins + Number(amount || 0));
  await user.save();
  res.json({ message: 'کوائنز اپڈیٹ ہو گئے', coins: user.coins });
});

// GET /api/admin/matches/live -> currently active matches
router.get('/matches/live', async (req, res) => {
  const matches = await Match.find({ status: { $in: ['waiting', 'active'] } })
    .populate('players.user', 'username')
    .sort({ createdAt: -1 })
    .limit(100);
  res.json({ matches });
});

// GET /api/admin/matches -> match history
router.get('/matches', async (req, res) => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Number(req.query.limit) || 25);
  const [matches, total] = await Promise.all([
    Match.find({ status: { $in: ['finished', 'abandoned'] } })
      .populate('players.user', 'username')
      .populate('winnerUser', 'username')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit),
    Match.countDocuments({ status: { $in: ['finished', 'abandoned'] } }),
  ]);
  res.json({ matches, total, page, pages: Math.ceil(total / limit) });
});

module.exports = router;
