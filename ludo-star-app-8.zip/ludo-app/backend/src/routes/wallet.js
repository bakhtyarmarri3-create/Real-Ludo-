const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { publicUser } = require('../utils/token');

const router = express.Router();

// GET /api/wallet -> current coin balance + stats
router.get('/', requireAuth, async (req, res) => {
  res.json({ coins: req.user.coins, stats: req.user.stats });
});

module.exports = router;
