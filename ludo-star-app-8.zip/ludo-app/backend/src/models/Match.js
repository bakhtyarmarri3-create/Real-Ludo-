const mongoose = require('mongoose');

const matchSchema = new mongoose.Schema(
  {
    mode: {
      type: String,
      enum: ['2p', '4p', 'ai'],
      required: true,
    },
    betAmount: {
      type: Number,
      default: 0, // 0 for AI / practice matches
    },
    status: {
      type: String,
      enum: ['waiting', 'active', 'finished', 'abandoned'],
      default: 'waiting',
    },
    // Slot assignment: which color belongs to which user
    players: [
      {
        user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
        color: { type: String, enum: ['green', 'yellow', 'red', 'blue'] },
        isAI: { type: Boolean, default: false },
        socketId: { type: String, default: null },
        connected: { type: Boolean, default: true },
      },
    ],
    winnerColor: { type: String, default: null },
    winnerUser: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    potTotal: { type: Number, default: 0 },
    // Full serialized game state (positions, finished counts, turn index, etc.)
    gameState: { type: mongoose.Schema.Types.Mixed, default: null },
    startedAt: { type: Date, default: null },
    finishedAt: { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Match', matchSchema);
