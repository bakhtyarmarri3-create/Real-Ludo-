const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Match = require('../models/Match');
const engine = require('./ludoEngine');
const mm = require('./matchmaking');
const { chooseAIMove } = require('./aiBot');

const TURN_SECONDS = 20;
const MIN_BET = Number(process.env.MIN_BET_COINS || 50);

// matchId -> { state, timer, timeLeft, io }
const liveMatches = new Map();
// socketId -> { userId, matchId }
const socketInfo = new Map();

function registerLudoSockets(io) {
  // Auth middleware for sockets: client must send the JWT token on connection
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('لاگ ان درکار ہے'));
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(payload.id);
      if (!user || user.isBanned) return next(new Error('اجازت نہیں'));
      socket.userId = String(user._id);
      socket.username = user.username;
      next();
    } catch (err) {
      next(new Error('ٹوکن غلط ہے'));
    }
  });

  io.on('connection', async (socket) => {
    await User.findByIdAndUpdate(socket.userId, { isOnline: true });
    io.emit('presence:update'); // admins listening can refetch overview

    socket.on('disconnect', async () => {
      mm.removeUserFromAllQueues(socket.userId);
      await User.findByIdAndUpdate(socket.userId, { isOnline: false });
      handlePlayerDisconnect(io, socket);
      io.emit('presence:update');
    });

    // ---- MATCHMAKING ----
    socket.on('queue:join', async ({ mode, betAmount }) => {
      try {
        if (!['2p', '4p'].includes(mode)) {
          return socket.emit('error:message', 'غلط گیم موڈ');
        }
        const bet = Math.max(MIN_BET, Number(betAmount) || MIN_BET);
        const user = await User.findById(socket.userId);
        if (user.coins < bet) {
          return socket.emit('error:message', 'آپ کے پاس کافی کوائنز نہیں ہیں');
        }

        mm.addToQueue(mode, bet, { userId: socket.userId, socketId: socket.id, username: socket.username });
        socket.emit('queue:waiting', { mode, betAmount: bet });

        const formed = mm.tryFormMatch(mode, bet);
        if (formed) {
          await createMatchFromQueue(io, mode, bet, formed);
        }
      } catch (err) {
        console.error(err);
        socket.emit('error:message', 'میچ تلاش کرنے میں خرابی');
      }
    });

    socket.on('queue:leave', ({ mode, betAmount }) => {
      mm.removeFromQueue(mode, Number(betAmount), socket.userId);
      socket.emit('queue:left');
    });

    // ---- AI PRACTICE MATCH (instant, no coins) ----
    socket.on('ai:start', async () => {
      const matchDoc = await Match.create({
        mode: 'ai',
        betAmount: 0,
        status: 'active',
        players: [
          { user: socket.userId, color: 'green', isAI: false, socketId: socket.id },
          { user: null, color: 'yellow', isAI: true },
          { user: null, color: 'red', isAI: true },
          { user: null, color: 'blue', isAI: true },
        ],
        startedAt: new Date(),
      });
      const state = engine.createInitialState(['green', 'yellow', 'red', 'blue']);
      const matchId = String(matchDoc._id);
      liveMatches.set(matchId, { state, io, mode: 'ai', betAmount: 0, players: matchDoc.players, timeLeft: TURN_SECONDS });
      socketInfo.set(socket.id, { userId: socket.userId, matchId });
      socket.join(matchId);

      socket.emit('match:start', {
        matchId,
        mode: 'ai',
        betAmount: 0,
        yourColor: 'green',
        players: [{ username: socket.username, color: 'green' }, { username: 'Computer 1', color: 'yellow' }, { username: 'Computer 2', color: 'red' }, { username: 'Computer 3', color: 'blue' }],
        state,
      });
      startTurnTimer(matchId);
    });

    // ---- IN-MATCH ACTIONS ----
    socket.on('game:roll', ({ matchId }) => handleRoll(io, socket, matchId));
    socket.on('game:move', ({ matchId, pieceId }) => handleMove(io, socket, matchId, pieceId));
    socket.on('game:emoji', ({ matchId, emoji }) => {
      const info = liveMatches.get(matchId);
      if (!info) return;
      const player = info.players.find((p) => String(p.user) === socket.userId);
      if (player) {
        io.to(matchId).emit('game:emoji', { color: player.color, emoji, username: socket.username });
      }
    });
  });
}

async function createMatchFromQueue(io, mode, betAmount, queueEntries) {
  const colors = mode === '4p' ? ['green', 'yellow', 'red', 'blue'] : ['green', 'red'];

  // Deduct the bet from every player up-front; abort match if anyone fails (e.g. spent coins meanwhile)
  const users = await User.find({ _id: { $in: queueEntries.map((e) => e.userId) } });
  for (const u of users) {
    if (u.coins < betAmount) {
      queueEntries.forEach((e) => io.to(e.socketId).emit('error:message', 'میچ منسوخ - کوائنز کم ہیں'));
      return;
    }
  }
  for (const u of users) {
    u.coins -= betAmount;
    await u.save();
    io.to(queueEntries.find((e) => String(e.userId) === String(u._id))?.socketId).emit('wallet:update', { coins: u.coins });
  }

  const players = queueEntries.map((e, idx) => ({
    user: e.userId,
    color: colors[idx],
    isAI: false,
    socketId: e.socketId,
    connected: true,
  }));

  const matchDoc = await Match.create({
    mode,
    betAmount,
    status: 'active',
    players,
    potTotal: betAmount * players.length,
    startedAt: new Date(),
  });

  const matchId = String(matchDoc._id);
  const state = engine.createInitialState(colors);
  liveMatches.set(matchId, { state, io, mode, betAmount, players, timeLeft: TURN_SECONDS });

  const playerList = players.map((p) => {
    const u = users.find((x) => String(x._id) === String(p.user));
    return { username: u.username, color: p.color };
  });

  players.forEach((p) => {
    const sock = io.sockets.sockets.get(p.socketId);
    if (sock) {
      sock.join(matchId);
      socketInfo.set(sock.id, { userId: p.user, matchId });
      sock.emit('match:start', {
        matchId,
        mode,
        betAmount,
        yourColor: p.color,
        players: playerList,
        state,
      });
    }
  });

  startTurnTimer(matchId);
}

function startTurnTimer(matchId) {
  const info = liveMatches.get(matchId);
  if (!info) return;
  clearInterval(info.timer);
  info.timeLeft = TURN_SECONDS;
  info.io.to(matchId).emit('turn:timer', { timeLeft: info.timeLeft, color: engine.currentColor(info.state) });

  info.timer = setInterval(() => {
    info.timeLeft--;
    info.io.to(matchId).emit('turn:timer', { timeLeft: info.timeLeft, color: engine.currentColor(info.state) });
    if (info.timeLeft <= 0) {
      const result = engine.forceSkipTurn(info.state);
      info.io.to(matchId).emit('turn:skipped', { nextTurnColor: result.nextTurnColor });
      startTurnTimer(matchId);
      maybeTriggerAI(matchId);
    }
  }, 1000);
}

function handleRoll(io, socket, matchId) {
  const info = liveMatches.get(matchId);
  if (!info) return socket.emit('error:message', 'میچ نہیں ملا');
  const player = info.players.find((p) => String(p.user) === socket.userId);
  if (!player) return socket.emit('error:message', 'آپ اس میچ میں نہیں ہیں');

  const result = engine.rollDice(info.state, player.color);
  if (!result.ok) return socket.emit('error:message', result.message);

  io.to(matchId).emit('game:rolled', { color: player.color, value: result.value, movable: result.movable });

  if (result.movable.length === 0) {
    setTimeout(() => {
      const skip = engine.forceSkipTurn(info.state);
      io.to(matchId).emit('turn:skipped', { nextTurnColor: skip.nextTurnColor });
      startTurnTimer(matchId);
      maybeTriggerAI(matchId);
    }, 900);
  }
}

async function handleMove(io, socket, matchId, pieceId) {
  const info = liveMatches.get(matchId);
  if (!info) return socket.emit('error:message', 'میچ نہیں ملا');
  const player = info.players.find((p) => String(p.user) === socket.userId);
  if (!player) return socket.emit('error:message', 'آپ اس میچ میں نہیں ہیں');

  const result = engine.movePiece(info.state, player.color, pieceId);
  if (!result.ok) return socket.emit('error:message', result.message);

  io.to(matchId).emit('game:moved', result);

  if (result.finishedAll) {
    await finishMatch(io, matchId, result.winnerColor);
    return;
  }

  startTurnTimer(matchId);
  maybeTriggerAI(matchId);
}

// If it's now an AI bot's turn, make the bot roll and move automatically.
function maybeTriggerAI(matchId) {
  const info = liveMatches.get(matchId);
  if (!info || info.mode !== 'ai') return;
  const color = engine.currentColor(info.state);
  const player = info.players.find((p) => p.color === color);
  if (!player || !player.isAI) return;

  setTimeout(() => {
    const rollResult = engine.rollDice(info.state, color);
    if (!rollResult.ok) return;
    info.io.to(matchId).emit('game:rolled', { color, value: rollResult.value, movable: rollResult.movable });

    if (rollResult.movable.length === 0) {
      setTimeout(() => {
        const skip = engine.forceSkipTurn(info.state);
        info.io.to(matchId).emit('turn:skipped', { nextTurnColor: skip.nextTurnColor });
        startTurnTimer(matchId);
        maybeTriggerAI(matchId);
      }, 800);
      return;
    }

    setTimeout(() => {
      const pieceId = chooseAIMove(info.state, color);
      const moveResult = engine.movePiece(info.state, color, pieceId);
      if (!moveResult.ok) return;
      info.io.to(matchId).emit('game:moved', moveResult);

      if (moveResult.finishedAll) {
        finishMatch(info.io, matchId, moveResult.winnerColor);
        return;
      }
      startTurnTimer(matchId);
      maybeTriggerAI(matchId);
    }, 1000);
  }, 900);
}

async function finishMatch(io, matchId, winnerColor) {
  const info = liveMatches.get(matchId);
  if (!info) return;
  clearInterval(info.timer);

  const matchDoc = await Match.findById(matchId);
  if (!matchDoc) return;

  const winnerPlayer = info.players.find((p) => p.color === winnerColor);

  if (info.mode !== 'ai' && winnerPlayer && winnerPlayer.user) {
    const pot = info.betAmount * info.players.length;
    const winnerUser = await User.findById(winnerPlayer.user);
    if (winnerUser) {
      winnerUser.coins += pot;
      winnerUser.stats.gamesWon += 1;
      winnerUser.stats.coinsWon += pot - info.betAmount;
      await winnerUser.save();
    }
    // update stats for losers
    for (const p of info.players) {
      if (!p.user || String(p.user) === String(winnerPlayer.user)) continue;
      const u = await User.findById(p.user);
      if (u) {
        u.stats.gamesPlayed += 1;
        u.stats.coinsLost += info.betAmount;
        await u.save();
      }
    }
    if (winnerUser) winnerUser.stats.gamesPlayed += 1; // count winner's game too
    if (winnerUser) await winnerUser.save();

    matchDoc.potTotal = pot;
    matchDoc.winnerUser = winnerPlayer.user;

    // notify clients of new balances
    for (const p of info.players) {
      if (!p.user) continue;
      const u = await User.findById(p.user);
      const sock = io.sockets.sockets.get(p.socketId);
      if (sock && u) sock.emit('wallet:update', { coins: u.coins });
    }
  }

  matchDoc.status = 'finished';
  matchDoc.winnerColor = winnerColor;
  matchDoc.finishedAt = new Date();
  matchDoc.gameState = info.state;
  await matchDoc.save();

  io.to(matchId).emit('match:finished', {
    winnerColor,
    potTotal: matchDoc.potTotal,
  });

  liveMatches.delete(matchId);
}

function handlePlayerDisconnect(io, socket) {
  const info = socketInfo.get(socket.id);
  if (!info) return;
  const matchInfo = liveMatches.get(info.matchId);
  if (!matchInfo) return;
  const player = matchInfo.players.find((p) => String(p.user) === String(info.userId));
  if (player) player.connected = false;
  io.to(info.matchId).emit('player:disconnected', { color: player?.color });
  socketInfo.delete(socket.id);
}

module.exports = { registerLudoSockets };
