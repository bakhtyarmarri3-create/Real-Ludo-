// Server-side authoritative Ludo engine.
// This mirrors the rules from the user's original HTML game,
// but runs on the server so no player can cheat by editing client code.

const COLORS_4P = ['green', 'yellow', 'red', 'blue'];
const START_OFFSET = { green: 0, yellow: 13, blue: 26, red: 39 };
const SAFE_ABS = [0, 8, 13, 21, 26, 34, 39, 47];

function createInitialState(colors) {
  const positions = {};
  const finished = {};
  colors.forEach((c) => {
    positions[c] = [-1, -1, -1, -1];
    finished[c] = 0;
  });
  return {
    colors, // ordered list of colors actually in play (2 or 4)
    turnIndex: 0,
    positions,
    finished,
    diceValue: 0,
    rolled: false,
    consecSixes: 0,
    winnerColor: null,
  };
}

function currentColor(state) {
  return state.colors[state.turnIndex];
}

function rollDice(state, color) {
  if (color !== currentColor(state)) {
    return { ok: false, message: 'یہ آپ کی باری نہیں' };
  }
  if (state.rolled) {
    return { ok: false, message: 'پہلے گوٹی چلائیں' };
  }
  const value = Math.ceil(Math.random() * 6);
  state.diceValue = value;
  state.rolled = true;

  const movable = movablePieces(state, color, value);
  return { ok: true, value, movable };
}

function movablePieces(state, color, dice) {
  const arr = state.positions[color];
  const movable = [];
  arr.forEach((pos, idx) => {
    if (pos === -1) {
      if (dice === 6) movable.push(idx);
    } else if (pos >= 0 && pos <= 56) {
      if (pos + dice <= 57) movable.push(idx);
    }
  });
  return movable;
}

function checkCapture(state, movedColor, pos) {
  const captured = [];
  if (pos > 50) return captured;
  const myAbs = (START_OFFSET[movedColor] + pos) % 52;
  if (SAFE_ABS.includes(myAbs)) return captured;

  state.colors.forEach((other) => {
    if (other === movedColor) return;
    state.positions[other].forEach((otherPos, otherIdx) => {
      if (otherPos >= 0 && otherPos <= 50) {
        const otherAbs = (START_OFFSET[other] + otherPos) % 52;
        if (otherAbs === myAbs) {
          state.positions[other][otherIdx] = -1;
          captured.push({ color: other, pieceId: otherIdx });
        }
      }
    });
  });
  return captured;
}

function movePiece(state, color, pieceId) {
  if (!state.rolled) return { ok: false, message: 'پہلے ڈائس دبائیں' };
  if (color !== currentColor(state)) return { ok: false, message: 'یہ آپ کی باری نہیں' };

  const movable = movablePieces(state, color, state.diceValue);
  if (!movable.includes(pieceId)) {
    return { ok: false, message: 'یہ گوٹی ابھی نہیں چل سکتی' };
  }

  let pos = state.positions[color][pieceId];
  pos = pos === -1 ? 0 : pos + state.diceValue;
  state.positions[color][pieceId] = pos;

  let reachedHome = false;
  let captured = [];

  if (pos === 57) {
    state.finished[color]++;
    reachedHome = true;
  } else {
    captured = checkCapture(state, color, pos);
  }

  const wasSix = state.diceValue === 6;
  const finishedAll = state.finished[color] === 4;

  state.rolled = false;
  const prevDice = state.diceValue;
  state.diceValue = 0;

  let extraTurn = false;
  if (finishedAll) {
    state.winnerColor = color;
  } else if (wasSix) {
    state.consecSixes++;
    if (state.consecSixes >= 3) {
      state.consecSixes = 0;
      advanceTurn(state);
    } else {
      extraTurn = true;
    }
  } else {
    state.consecSixes = 0;
    advanceTurn(state);
  }

  return {
    ok: true,
    color,
    pieceId,
    newPos: pos,
    diceValueUsed: prevDice,
    reachedHome,
    captured,
    extraTurn,
    finishedAll,
    winnerColor: state.winnerColor,
    nextTurnColor: currentColor(state),
  };
}

function advanceTurn(state) {
  state.turnIndex = (state.turnIndex + 1) % state.colors.length;
  state.diceValue = 0;
  state.rolled = false;
}

// Called when a player runs out of time or has no valid moves
function forceSkipTurn(state) {
  state.consecSixes = 0;
  advanceTurn(state);
  return { nextTurnColor: currentColor(state) };
}

module.exports = {
  createInitialState,
  currentColor,
  rollDice,
  movablePieces,
  movePiece,
  forceSkipTurn,
  COLORS_4P,
};
