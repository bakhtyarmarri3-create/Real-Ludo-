// Very simple bot logic for AI practice matches (no coins at stake).
// Picks a sensible move: prefers capturing > finishing a piece > bringing a new piece out > advancing furthest piece.

const { movablePieces } = require('./ludoEngine');

const START_OFFSET = { green: 0, yellow: 13, blue: 26, red: 39 };
const SAFE_ABS = [0, 8, 13, 21, 26, 34, 39, 47];

function wouldCapture(state, color, pieceId) {
  const pos = state.positions[color][pieceId];
  const newPos = pos === -1 ? 0 : pos + state.diceValue;
  if (newPos > 50) return false;
  const myAbs = (START_OFFSET[color] + newPos) % 52;
  if (SAFE_ABS.includes(myAbs)) return false;
  return state.colors.some((other) => {
    if (other === color) return false;
    return state.positions[other].some((otherPos) => {
      if (otherPos < 0 || otherPos > 50) return false;
      const otherAbs = (START_OFFSET[other] + otherPos) % 52;
      return otherAbs === myAbs;
    });
  });
}

function chooseAIMove(state, color) {
  const movable = movablePieces(state, color, state.diceValue);
  if (movable.length === 0) return null;

  // 1. Prefer a capture
  const capturing = movable.find((id) => wouldCapture(state, color, id));
  if (capturing !== undefined) return capturing;

  // 2. Prefer finishing a piece (reaching home, pos 57)
  const finishing = movable.find((id) => {
    const pos = state.positions[color][id];
    return pos !== -1 && pos + state.diceValue === 57;
  });
  if (finishing !== undefined) return finishing;

  // 3. Prefer bringing a new piece out on a 6
  if (state.diceValue === 6) {
    const newPiece = movable.find((id) => state.positions[color][id] === -1);
    if (newPiece !== undefined) return newPiece;
  }

  // 4. Otherwise move the piece that's furthest along (closest to home)
  let best = movable[0];
  movable.forEach((id) => {
    if (state.positions[color][id] > state.positions[color][best]) best = id;
  });
  return best;
}

module.exports = { chooseAIMove };
