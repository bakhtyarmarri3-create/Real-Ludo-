// Simple in-memory matchmaking queues, separated by mode and bet amount.
// Key format: "2p:100" or "4p:500"
// NOTE: this resets if the server restarts. For a small/medium app this is fine.
// If you outgrow this, move the queue into Redis.

const queues = new Map();

function queueKey(mode, betAmount) {
  return `${mode}:${betAmount}`;
}

function getQueue(mode, betAmount) {
  const key = queueKey(mode, betAmount);
  if (!queues.has(key)) queues.set(key, []);
  return queues.get(key);
}

function addToQueue(mode, betAmount, entry) {
  const q = getQueue(mode, betAmount);
  q.push(entry);
}

function removeFromQueue(mode, betAmount, userId) {
  const q = getQueue(mode, betAmount);
  const idx = q.findIndex((e) => String(e.userId) === String(userId));
  if (idx !== -1) q.splice(idx, 1);
}

function removeUserFromAllQueues(userId) {
  for (const q of queues.values()) {
    const idx = q.findIndex((e) => String(e.userId) === String(userId));
    if (idx !== -1) q.splice(idx, 1);
  }
}

// Returns an array of entries to start a match if enough players are queued, else null
function tryFormMatch(mode, betAmount) {
  const needed = mode === '4p' ? 4 : 2;
  const q = getQueue(mode, betAmount);
  if (q.length >= needed) {
    return q.splice(0, needed);
  }
  return null;
}

module.exports = {
  addToQueue,
  removeFromQueue,
  removeUserFromAllQueues,
  tryFormMatch,
  getQueue,
};
