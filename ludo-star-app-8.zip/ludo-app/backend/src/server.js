require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const { Server } = require('socket.io');

const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const walletRoutes = require('./routes/wallet');
const { registerLudoSockets } = require('./sockets/gameHandler');

const app = express();
const server = http.createServer(app);

const CLIENT_URL = process.env.CLIENT_URL || 'http://localhost:5173';

app.use(cors({ origin: CLIENT_URL, credentials: true }));
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/wallet', walletRoutes);

const io = new Server(server, {
  cors: { origin: CLIENT_URL, credentials: true },
});
registerLudoSockets(io);

const PORT = process.env.PORT || 5000;

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log('MongoDB سے کنکشن کامیاب');
    server.listen(PORT, () => console.log(`سرور چل رہا ہے: http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('MongoDB کنکشن میں خرابی:', err.message);
    process.exit(1);
  });
