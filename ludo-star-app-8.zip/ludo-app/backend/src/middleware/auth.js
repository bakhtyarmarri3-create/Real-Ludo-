const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Verifies the Bearer token sent by the frontend and attaches the user to req.user
async function requireAuth(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) {
      return res.status(401).json({ message: 'لاگ ان درکار ہے' });
    }
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.id);
    if (!user) {
      return res.status(401).json({ message: 'یوزر نہیں ملا' });
    }
    if (user.isBanned) {
      return res.status(403).json({ message: 'آپ کا اکاؤنٹ بلاک کر دیا گیا ہے' });
    }
    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'ٹوکن غلط یا ختم ہو گیا ہے' });
  }
}

// Only allows users with role === 'admin'
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'صرف ایڈمن کے لیے' });
  }
  next();
}

module.exports = { requireAuth, requireAdmin };
