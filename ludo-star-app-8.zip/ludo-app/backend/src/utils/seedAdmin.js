require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

async function seedAdmin() {
  await mongoose.connect(process.env.MONGO_URI);

  const email = (process.env.ADMIN_EMAIL || 'admin@ludostar.com').toLowerCase();
  const password = process.env.ADMIN_PASSWORD || 'ChangeThisPassword123';

  const existing = await User.findOne({ email });
  if (existing) {
    if (existing.role !== 'admin') {
      existing.role = 'admin';
      await existing.save();
      console.log('موجودہ یوزر کو ایڈمن بنا دیا گیا:', email);
    } else {
      console.log('ایڈمن اکاؤنٹ پہلے سے موجود ہے:', email);
    }
  } else {
    const passwordHash = await bcrypt.hash(password, 10);
    await User.create({
      username: 'admin',
      email,
      passwordHash,
      role: 'admin',
      coins: 0,
    });
    console.log('نیا ایڈمن اکاؤنٹ بن گیا:', email, '/ پاس ورڈ:', password);
  }

  await mongoose.disconnect();
  process.exit(0);
}

seedAdmin().catch((err) => {
  console.error(err);
  process.exit(1);
});
