const jwt = require('jsonwebtoken');

function signToken(user) {
  return jwt.sign(
    { id: user._id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '30d' }
  );
}

function publicUser(user) {
  return {
    id: user._id,
    username: user.username,
    email: user.email,
    role: user.role,
    coins: user.coins,
    lastBonusClaimedAt: user.lastBonusClaimedAt,
    stats: user.stats,
  };
}

module.exports = { signToken, publicUser };
