# 🎲 Ludo Star — مکمل گائیڈ (اردو)

یہ پروجیکٹ دو حصوں میں ہے:
- **backend/** → سرور (لاگ ان، والٹ، میچ میکنگ، گیم لاجک، ایڈمن) — یہ **Render** پر چلے گا
- **frontend/** → ویب ایپ (ڈیش بورڈ، گیم بورڈ، ایڈمن پینل) — یہ **Vercel** پر چلے گا

⚠️ یہ یاد رکھیں: یہ ایک سرور-بیسڈ ایپ ہے، اس لیے صرف frontend اپلوڈ کرنے سے کچھ نہیں چلے گا۔ backend بھی الگ سے deploy کرنا ضروری ہے۔

---

## مرحلہ 1: MongoDB ڈیٹابیس بنائیں (مفت)

1. https://www.mongodb.com/cloud/atlas/register پر جا کر فری اکاؤنٹ بنائیں
2. "Build a Database" → **M0 Free** پلان منتخب کریں → کوئی بھی region چن لیں → Create
3. جب پوچھے Username/Password بنائیں (یاد رکھیں، بعد میں چاہیے ہوں گے)
4. "Network Access" میں جا کر **Add IP Address** → **Allow Access from Anywhere** (0.0.0.0/0) منتخب کریں — یہ ضروری ہے ورنہ Render کنیکٹ نہیں ہو سکے گا
5. "Database" → اپنے کلسٹر پر **Connect** بٹن دبائیں → "Drivers" منتخب کریں → آپ کو ایک کنکشن سٹرنگ ملے گی جو ایسی نظر آئے گی:
   ```
   mongodb+srv://USERNAME:PASSWORD@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
6. اس میں `USERNAME` اور `PASSWORD` کو اپنی اصل ویلیوز سے بدل دیں، اور `.net/` کے بعد `ludostar` لکھ دیں تاکہ یہ ایسا بنے:
   ```
   mongodb+srv://USERNAME:PASSWORD@cluster0.xxxxx.mongodb.net/ludostar?retryWrites=true&w=majority
   ```
   یہی آپ کا `MONGO_URI` ہے — اسے کہیں محفوظ کر لیں۔

---

## مرحلہ 2: GitHub پر کوڈ اپلوڈ کریں

1. https://github.com پر جا کر دو نئے ریپوزٹری بنائیں (یا ایک ہی ریپو میں دو فولڈرز رکھیں — نیچے دونوں طریقے بتائے گئے ہیں)

**آسان طریقہ: ایک ہی ریپو میں دونوں فولڈرز**
```
ludo-app/
  backend/
  frontend/
```
بس اس پورے `ludo-app` فولڈر کو ایک GitHub ریپو میں اپلوڈ کر دیں (GitHub Desktop استعمال کریں یا ویب پر "Upload files" سے)۔

---

## مرحلہ 3: Backend کو Render پر Deploy کریں

1. https://render.com پر جا کر اکاؤنٹ بنائیں (GitHub سے سائن ان کر سکتے ہیں)
2. Dashboard میں **New +** → **Web Service** پر کلک کریں
3. اپنا GitHub ریپو منتخب کریں
4. سیٹنگز یہ رکھیں:
   - **Name:** ludo-backend (یا کوئی بھی نام)
   - **Root Directory:** `backend`
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Plan:** Free
5. نیچے "Environment Variables" میں یہ سب شامل کریں:

   | Key | Value |
   |---|---|
   | `MONGO_URI` | وہ کنکشن سٹرنگ جو مرحلہ 1 میں بنائی |
   | `JWT_SECRET` | کوئی بھی لمبی رینڈم سٹرنگ (مثلاً 40 حروف کا کوئی پاس ورڈ) |
   | `CLIENT_URL` | ابھی `http://localhost:5173` رکھیں، Vercel deploy کے بعد بدل دیں گے |
   | `ADMIN_EMAIL` | اپنا ایڈمن ای میل، مثلاً admin@ludostar.com |
   | `ADMIN_PASSWORD` | اپنا ایڈمن پاس ورڈ |
   | `SIGNUP_BONUS_COINS` | `5000` |
   | `DAILY_BONUS_COINS` | `5000` |
   | `DAILY_BONUS_HOURS` | `24` |
   | `MIN_BET_COINS` | `50` |

6. **Create Web Service** پر کلک کریں۔ کچھ منٹ میں deploy ہو جائے گا۔
7. جب deploy مکمل ہو جائے، آپ کو ایک URL ملے گا جیسے:
   ```
   https://ludo-backend.onrender.com
   ```
   یہ نوٹ کر لیں — یہی آپ کا **backend URL** ہے۔

### ایڈمن اکاؤنٹ بنانا
Render کے Dashboard میں اپنی سروس کھولیں → **Shell** ٹیب پر جائیں (یا اپنے کمپیوٹر پر مکمل کوڈ ڈاؤن لوڈ کر کے مقامی طور پر چلائیں) → یہ کمانڈ چلائیں:
```
npm run seed:admin
```
یہ آپ کے دیے گئے `ADMIN_EMAIL`/`ADMIN_PASSWORD` سے ایڈمن اکاؤنٹ بنا دے گا۔ اگر آپ نے پہلے ہی اس ای میل سے عام اکاؤنٹ بنا لیا ہے، یہ اسے خودکار طور پر ایڈمن بنا دے گا۔

⚠️ **نوٹ:** Render کا فری پلان کچھ دیر بے استعمال رہنے پر سرور کو "sleep" کر دیتا ہے، اور پہلی ریکویسٹ پر دوبارہ اٹھنے میں 30-60 سیکنڈ لگ سکتے ہیں۔ یہ مفت پلان کی فطری بات ہے۔

---

## مرحلہ 4: Frontend کو Vercel پر Deploy کریں

1. سب سے پہلے `frontend/.env.example` کو `frontend/.env` کے نام سے کاپی کریں اور اس میں اپنا backend URL ڈالیں:
   ```
   VITE_API_URL=https://ludo-backend.onrender.com
   ```
2. https://vercel.com پر جا کر GitHub سے سائن ان کریں
3. **Add New** → **Project** → اپنا ریپو منتخب کریں
4. سیٹنگز:
   - **Root Directory:** `frontend`
   - **Framework Preset:** Vite (خودکار detect ہو جائے گا)
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
5. **Environment Variables** میں شامل کریں:
   | Key | Value |
   |---|---|
   | `VITE_API_URL` | آپ کا backend URL، مثلاً `https://ludo-backend.onrender.com` |
6. **Deploy** پر کلک کریں۔ کچھ منٹ میں آپ کو ایک لائیو لنک ملے گا جیسے:
   ```
   https://ludo-star.vercel.app
   ```

---

## مرحلہ 5: Backend کو بتائیں کہ آپ کا Frontend کہاں ہے

اب واپس Render پر جائیں → اپنی backend سروس → Environment میں `CLIENT_URL` کو اپنے Vercel لنک سے بدل دیں:
```
CLIENT_URL=https://ludo-star.vercel.app
```
سیو کریں — سروس خودکار طور پر دوبارہ deploy ہو جائے گی۔ یہ ضروری ہے ورنہ CORS کی وجہ سے frontend backend سے بات نہیں کر سکے گا۔

---

## ✅ اب آپ کی ایپ لائیو ہے

اپنا Vercel لنک کسی کو بھی بھیجیں — وہ رجسٹر کر کے کھیل سکتے ہیں۔ اگر دو الگ لوگ الگ جگہوں سے ایک ہی وقت میں ایک ہی بیٹ امونٹ اور موڈ پر "کھیلنا شروع کریں" دبائیں، وہ خودکار طور پر آپس میں جڑ جائیں گے۔

---

## فیچرز کا خلاصہ — کیا بن گیا

- ✅ رجسٹر/لاگ ان (محفوظ پاس ورڈ کے ساتھ)
- ✅ سائن اپ پر 5000 کوائنز
- ✅ روزانہ بونس (5000 کوائنز ہر 24 گھنٹے بعد) — سرور پر چیک ہوتا ہے، کوئی دھوکہ نہیں کر سکتا
- ✅ 2 پلیئر اور 4 پلیئر موڈ
- ✅ بیٹ امونٹ منتخب کرنا (50 سے اوپر، جتنا چاہیں)
- ✅ حقیقی وقت میں دو/چار مختلف لوگوں کا میچ بننا (matchmaking)
- ✅ آپ کا اصل Ludo بورڈ ڈیزائن (رنگ، گوٹیاں، ڈائس، ایموجی) — بالکل ویسا ہی محفوظ رکھا گیا
- ✅ جیتنے والے کو پورا pot (سارے کوائنز) ملنا
- ✅ کمپیوٹر (AI) کے خلاف مفت پریکٹس گیم
- ✅ ایڈمن پینل: کل یوزرز، آن لائن یوزرز، کل کوائنز، لائیو میچز، یوزرز کی تفصیل، بلاک/ان بلاک، کوائنز ایڈجسٹ کرنا

## آپ کو خود کیا کرنا ہوگا (دوبارہ خلاصہ)

1. MongoDB Atlas اکاؤنٹ بنانا اور کنکشن سٹرنگ لینا
2. GitHub پر کوڈ اپلوڈ کرنا
3. Render پر backend deploy کرنا + environment variables بھرنا
4. ایک بار `npm run seed:admin` چلانا (ایڈمن اکاؤنٹ بنانے کے لیے)
5. Vercel پر frontend deploy کرنا + `VITE_API_URL` سیٹ کرنا
6. Render پر واپس جا کر `CLIENT_URL` کو اصل Vercel لنک سے اپڈیٹ کرنا

## مستقبل میں بہتری کے خیالات (اختیاری)

- لائیو میچز کی لسٹ کو Socket سے realtime بنانا (ابھی ایڈمن پینل ہر 5 سیکنڈ بعد خودکار ریفریش ہوتا ہے، یہ کافی ہے مگر مزید بہتر کیا جا سکتا ہے)
- پروفائل تصویر/ایویٹار کا اضافہ
- لیڈر بورڈ (سب سے زیادہ جیتنے والے یوزرز کی لسٹ)
- موبائل ایپ (React Native میں یہی بیک اینڈ استعمال کر کے)

اگر کسی مرحلے پر کوئی ایرر آئے، وہ ایرر کا پورا میسج مجھے بھیجیں، میں بتا دوں گا مسئلہ کیا ہے۔
